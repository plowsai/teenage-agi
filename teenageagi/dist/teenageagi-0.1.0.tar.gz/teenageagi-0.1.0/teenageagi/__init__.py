"""
TeenageAGI - A Python package for teenage-agi
"""

__version__ = "0.1.0"

from .core import TeenageAGI, create_agent

__all__ = ["TeenageAGI", "create_agent"]
